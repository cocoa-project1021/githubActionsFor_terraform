﻿USE `tastylog`

INSERT INTO t_shop_category VALUES (6,17);
INSERT INTO t_shop_category VALUES (6,18);
INSERT INTO t_shop_category VALUES (12,81);
INSERT INTO t_shop_category VALUES (15,38);
INSERT INTO t_shop_category VALUES (34,179);
